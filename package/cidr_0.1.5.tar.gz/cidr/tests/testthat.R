library(testthat)
library(cidr)

test_check("cidr")
